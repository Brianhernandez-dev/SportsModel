# Comparison with approved Oct8 evidence

Shared: same orientation/Pacific date, extra physical row invisible to MLB history,
clear real event, no authoritative/betting state on the extra row in scoped evidence,
and H-1 duplicate-count/invisibility risk. These do not alone establish034 eligibility.

Oct8:11408/11409 have different retained Odds external IDs, genuine provider
observations, one observed co-existence run, commence-time evolution,30/58 raw
snapshots and a170–180-minute start discrepancy. Survivor849832 still needed
separate exact MLB anchor/history authority. Immutable0.9.1/design references
are recorded, not generalized into new executable authorization.

July29/586: one retained Odds ID on29, existing MLB mapping/history on586,
one-minute offset, legacy provenance with zero provider observations. No evidence
proves Odds reissuance/co-existence.584/26:584 has no source or raw market evidence;
26 owns Odds+MLB mappings and complete history, with a one-minute stored/official
start offset. Both July fixed survivors already have history; Oct8 reversal/history
assumptions cannot be copied. Identity conclusions are clearer than creation-cause
and provider-evolution conclusions. Current admissibility is explicitly different.
