# Creation and observation timeline

| UTC | Pacific | Evidence |
| --- | --- | --- |
| 2026-10-08T01:30:04.184076+00:00 | 2026-10-07T18:30:04.184076-07:00 | Run516 started, opening |
| 2026-10-08T01:30:04.795941+00:00 | 2026-10-07T18:30:04.795941-07:00 | Old Odds event first observed; commence21:00Z; observation2412 |
| 2026-10-08T01:30:04.823559+00:00 | 2026-10-07T18:30:04.823559-07:00 | Run516 complete, observation created_at, source12223 naive created_at agrees |
| 2026-10-08T01:45:06.426891+00:00 | 2026-10-07T18:45:06.426891-07:00 | Preview110 created; separate date context |
| 2026-10-08T01:45:06.807103+00:00 | 2026-10-07T18:45:06.807103-07:00 | Preview110 complete,2received/2skipped/0predictions; not proof of two internal Odds identities |
| 2026-10-08T03:30:04.570980+00:00 | 2026-10-07T20:30:04.570980-07:00 | Run517 started, evening |
| 2026-10-08T03:30:04.986456+00:00 | 2026-10-07T20:30:04.986456-07:00 | BOTH Odds IDs observed:2413 old21:10Z,2414 new00:00Z |
| 2026-10-08T03:30:04.989039+00:00 | 2026-10-07T20:30:04.989039-07:00 | Run517 complete; new source12224 and both observation creation timestamps agree |
| 2026-10-08T06:00:03.720653+00:00 | 2026-10-07T23:00:03.720653-07:00 | Run518 late_night: only new event; observation2415 |
| 2026-10-08T13:00:04.689656+00:00 | 2026-10-08T06:00:04.689656-07:00 | Run519 morning: new event; observation2416 |
| 2026-10-08T19:00:04.965833+00:00 | 2026-10-08T12:00:04.965833-07:00 | Run520 afternoon: new event last retained observation2417 |
| 2026-10-09T00:00:00Z | 2026-10-08T17:00:00-07:00 | Authoritative MLB849832 scheduled start, nowFinal |
| 2026-10-09T14:15:09.332181+00:00 | 2026-10-09T07:15:09.332181-07:00 | Date-context workflow276 created pending/initialized; no official links |

Game insert timestamps are not stored. Their likely creation transactions are
inferred from source creation and exact ingestion/observation linkage. Do not
substitute inferred timestamps for nonexistent game-row created_at values.
Source timestamps without timezone are preserved verbatim in CSV/JSON.
