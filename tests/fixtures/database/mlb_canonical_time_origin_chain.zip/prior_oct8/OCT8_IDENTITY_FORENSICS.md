# October 8 canonical identity forensics

Disposition: OCT8_IDENTITY_DISPOSITION_READY_FOR_REVIEW.
This is a proposed identity disposition, not execution authority or cutover readiness.

## Complete current game-row comparison

| Field | 11408 | 11409 |
| --- | --- | --- |
| game_date UTC | 2026-10-08T21:00:00+00:00 | 2026-10-09T00:00:00+00:00 |
| Pacific game start | 2026-10-08T14:00:00-07:00 | 2026-10-08T17:00:00-07:00 |
| home_team_id/name | 81 / Chicago White Sox | 81 / Chicago White Sox |
| away_team_id/name | 76 / Cleveland Guardians | 76 / Cleveland Guardians |
| mlb_game_id | NULL | NULL |
| odds_api_event_id (legacy games field) | NULL | NULL |
| scheduled_innings | NULL | NULL |
| doubleheader_status | NULL | NULL |
| game_number | NULL | NULL |
| created_at / updated_at / status fields | Columns absent | Columns absent |
| source row ID | 12223 | 12224 |
| source_name | odds_api | odds_api |
| external_game_id | e0448f7b831a9ecc0580ba4295270d0c | b57e790481f2b8e5eaf9e0f3eab816bc |
| source created_at (TIMESTAMP WITHOUT TIME ZONE) | 2026-10-08T01:30:04.823559 | 2026-10-08T03:30:04.989039 |
| source updated_at | Column absent | Column absent |
| physical market snapshot rows | 30 | 58 |
| provider observation rows | 2 | 4 |
| linked authoritative result/team/pitcher rows | 0 / 0 / 0 | 0 / 0 / 0 |
| linked predictions/evaluations/settlements | 0 / 0 / 0 | 0 / 0 / 0 |

These are every current `games` column, not selected-field summaries. Source IDs are
different; neither ID appears as two game_sources mappings. Both have exactly one
Odds mapping and no MLB or other source. The legacy NULL fields are not evidence of
no provider identity: identity resides in game_sources. No direct creation timestamp
exists for either game. Source times are naive database values; their UTC interpretation
is corroborated by identical timezone-aware observation/run transaction timestamps,
not silently assumed from column type.

## Authoritative identity

One anonymous Oct8 MLB Stats schedule GET returned exactly one game: 849832,
officialDate 2026-10-08, gameDate 2026-10-09T00:00:00Z, home145 Chicago White Sox,
away114 Cleveland Guardians, typeD, Final, startTimeTBD=false, ifNecessary=N,
doubleHeader=N, gameNumber=1, scheduledInnings=9. No reschedule/resume fields were
supplied. It matches11409 exactly, not11408 three hours earlier. Current evidence
does not identify a second real game, doubleheader or suspended continuation. A
current schedule cannot prove that historical provider scheduling never changed.

## How two records arose

Run516 opening observed old event at01:30:04.795941Z for21:00Z. Run517 evening
observed BOTH IDs at03:30:04.986456Z: old event now21:10Z and new event00:00Z.
Both acquired markets concurrently. Old event then disappeared from the retained
later runs518–520 while the new event persisted through19:00:04.965833Z.

Production odds_api.py:649–662 resolves each distinct provider event through the
canonical matcher. Existing-ID branch returns11408 without updating its start,
so the ten-minute commence drift remains observation evidence, not a games update.
For the new ID, there was no MLB mapping and the old row was outside15minutes.
Same-Pacific-date fallback excludes a row already mapped by the same source
(game_matching.py:289–318). Therefore the fallback did not reuse11408 and the
zero-candidate branch created a new row at:336–355. Source insertion follows.

This identifies the local causal mechanism: concurrent distinct Odds IDs plus
same-source exclusion/time tolerance created two Odds-first identities. It was
not a Pacific-date boundary or reversed orientation. Schedule drift within one
unchanged ID alone did not create11409. A stale/reissued upstream event is supported
as a hypothesis, but the provider's internal reason for emitting both IDs is unknown.
Raw full Odds responses were not found in inspected locations; no paid query made.

## Recommended labels

- 11409: AUTHORITATIVE_RECORD_CANDIDATE; HAS_MARKET_ONLY_HISTORY.
- 11408: STALE_DUPLICATE_CANDIDATE; HAS_MARKET_ONLY_HISTORY.
- Neither: HAS_BETTING_STATE or proven DISTINCT_REAL_EVENT.

The evidence is sufficient to submit the bounded disposition for independent review.
It is not sufficient to reinterpret old prices as valid wagering observations for
the corrected event or to claim upstream reissue causation with certainty.
