# Export scope and limitations

ODDS_TIMELINE contains 168 odds_market_snapshots and 9 legacy odds_snapshots.
The latter timestamps are naive and remain naive; do not order them against UTC
records by inventing a timezone. Both legacy Odds snapshots and market snapshots
are linked to current source mappings for context, not to invented raw provider
observations. Pair29/586 has raw evidence only on29;584/26 only on26, so there are
no raw rows on both sides within either pair to demonstrate overlap/replacement.
The nine legacy rows share their stored 2026-07-11T23:51:57.356466 timestamp.
Market-table first/last times are separately listed in ODDS_PROVENANCE_SUMMARY.

Team/pitching exports retain identity, orientation, source and PIT timestamps,
not batting/pitching performance values. Price/line/model-value columns are
excluded; unprojected row digests establish stability but cannot reconstruct
omitted values. No market transfer or price-performance analysis was performed.
NFL zero-row reference checks remain in the catalog/counts/attestation, not as
unnecessary separate payloads. Only four requested roots plus narrowly bounded
lineage/context and the existing14cohort are represented. Raw MLB Stats schedule
bytes preserve the complete single necessary date response unchanged.

READ_ONLY_SQL and EXECUTED_SELECTS are the second48query snapshot, including
three additional workflow checks. The first45queries/identity are under evidence/.
Production034 functions were not called on033; eligibility is reviewed code
inspection. Full prospective H-1 readiness, current starters, publication files,
workload/task health and all historical provider responses remain unverified.
Only the prior-context starter IDs344/510 and retained team IDs81/76 were supplied.
Four unresolved logical groups are placeholders, not four proven real events.
This evidence package is not a disposition/reconciliation/recovery authorization.
