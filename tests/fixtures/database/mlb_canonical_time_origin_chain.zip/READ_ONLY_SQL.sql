-- Parameters: null
SELECT current_database() AS database,host(inet_server_addr()) AS address,inet_server_port() AS port,version() AS version,pg_backend_pid() AS backend_pid,pg_postmaster_start_time() AS server_started,transaction_timestamp() AS snapshot_time,current_setting('transaction_read_only') AS read_only,current_setting('default_transaction_read_only') AS default_read_only,current_setting('transaction_isolation') AS isolation,current_setting('server_version_num') AS version_num;

-- Parameters: null
SELECT version,filename,checksum FROM schema_migrations ORDER BY version;

-- Parameters: null
SELECT c.table_name,c.column_name,c.data_type,c.udt_name FROM information_schema.columns c JOIN information_schema.tables t USING(table_schema,table_name) WHERE c.table_schema='public' AND t.table_type='BASE TABLE' ORDER BY c.table_name,c.ordinal_position;

-- Parameters: null
SELECT c.conname,ch.relname AS child_table,pa.relname AS parent_table,
      array_agg(ca.attname ORDER BY k.ord) AS child_columns,array_agg(ra.attname ORDER BY k.ord) AS parent_columns,
      pg_get_constraintdef(c.oid) AS definition FROM pg_constraint c JOIN pg_class ch ON ch.oid=c.conrelid
      JOIN pg_class pa ON pa.oid=c.confrelid CROSS JOIN LATERAL unnest(c.conkey,c.confkey) WITH ORDINALITY k(child_att,parent_att,ord)
      JOIN pg_attribute ca ON ca.attrelid=ch.oid AND ca.attnum=k.child_att
      JOIN pg_attribute ra ON ra.attrelid=pa.oid AND ra.attnum=k.parent_att
      WHERE c.contype='f' AND ch.relnamespace='public'::regnamespace AND pa.relnamespace='public'::regnamespace
      GROUP BY c.oid,c.conname,ch.relname,pa.relname ORDER BY ch.relname,c.conname;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."games" t WHERE game_id=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."game_results" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."game_sources" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."historical_games" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."model_predictions" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_game_predictions" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_paper_candidate_settlements" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_game_source_observations" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_games" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_moneyline_game_predictions" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_moneyline_market_evaluation_contributors" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_moneyline_market_evaluations" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_odds_provider_event_mappings" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_official_pregame_evidence" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_team_game_statistics" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."nfl_team_game_statistics_source_observations" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."odds_market_snapshots" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."odds_provider_event_canonical_corrections" t WHERE "original_game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."odds_provider_event_canonical_corrections" t WHERE "corrected_game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."odds_snapshots" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."player_game_pitching_statistics" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[29, 586, 584, 26]]
SELECT to_jsonb(t)::text AS row FROM public."team_game_statistics" t WHERE "game_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [["161be820330ad3e3e7e2ab5b0add2ff4", "fe2a389f5cf40c61156a794804ec0fff"]]
SELECT to_jsonb(t)::text AS row FROM public."odds_provider_event_observations" t WHERE source_name='odds_api' AND external_event_id=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370]]
SELECT to_jsonb(t)::text AS row FROM public."market_analysis" t WHERE "odds_market_snapshot_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370]]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_prediction_market_evaluations" t WHERE "odds_market_snapshot_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2]]
SELECT to_jsonb(t)::text AS row FROM public."odds_ingestion_runs" t WHERE "odds_ingestion_run_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2, 3, 5, 6, 8, 26, 27, 28]]
SELECT to_jsonb(t)::text AS row FROM public."sportsbooks" t WHERE "sportsbook_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2, 3, 6, 8, 26, 27, 28]]
SELECT to_jsonb(t)::text AS row FROM public."sportsbooks" t WHERE "sportsbook_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370]]
SELECT to_jsonb(t)::text AS row FROM public."market_analysis" t WHERE "odds_market_snapshot_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370]]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_prediction_market_evaluations" t WHERE "odds_market_snapshot_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2]]
SELECT to_jsonb(t)::text AS row FROM public."odds_ingestion_runs" t WHERE "odds_ingestion_run_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2, 3, 5, 6, 8, 26, 27, 28]]
SELECT to_jsonb(t)::text AS row FROM public."sportsbooks" t WHERE "sportsbook_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2, 3, 6, 8, 26, 27, 28]]
SELECT to_jsonb(t)::text AS row FROM public."sportsbooks" t WHERE "sportsbook_id"=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[26, 29, 584, 586, 11385, 11389, 11394, 11400, 11402, 11403, 11404, 11405, 11406, 11407, 11408, 11409]]
SELECT to_jsonb(g) AS game,(g.game_date AT TIME ZONE 'America/Los_Angeles')::date AS pacific_date,
      h.team_name AS home_team,a.team_name AS away_team,
      COALESCE((SELECT jsonb_agg(to_jsonb(s) ORDER BY game_source_id) FROM game_sources s WHERE s.game_id=g.game_id),'[]'::jsonb) AS sources,
      (SELECT count(*) FROM historical_games r WHERE r.game_id=g.game_id) AS result_rows,
      (SELECT count(*) FROM team_game_statistics r WHERE r.game_id=g.game_id) AS team_rows,
      (SELECT count(*) FROM player_game_pitching_statistics r WHERE r.game_id=g.game_id) AS pitching_rows
      FROM games g JOIN teams h ON h.team_id=g.home_team_id JOIN teams a ON a.team_id=g.away_team_id
      WHERE g.game_id=ANY(%s) ORDER BY g.game_id;

-- Parameters: [[29, 584, 11385, 11389, 11394, 11400, 11402, 11403, 11404, 11405, 11406, 11407, 11408, 11409]]
SELECT a.game_id AS cohort_game_id,b.game_id AS other_game_id,
      a.game_date AS cohort_start,b.game_date AS other_start,a.home_team_id,a.away_team_id,
      COALESCE((SELECT jsonb_agg(to_jsonb(s) ORDER BY game_source_id) FROM game_sources s WHERE s.game_id=b.game_id),'[]'::jsonb) AS other_sources
      FROM games a JOIN games b ON a.game_id<>b.game_id AND a.home_team_id=b.home_team_id AND a.away_team_id=b.away_team_id
      AND (a.game_date AT TIME ZONE 'America/Los_Angeles')::date=(b.game_date AT TIME ZONE 'America/Los_Angeles')::date
      WHERE a.game_id=ANY(%s) ORDER BY a.game_id,b.game_id;

-- Parameters: [11410]
SELECT to_jsonb(g) AS game FROM games g WHERE game_id=%s;

-- Parameters: [[81, 76], "2026-10-11 22:49:36.724858+00:00", [26, 29, 584, 586, 11385, 11389, 11394, 11400, 11402, 11403, 11404, 11405, 11406, 11407, 11408, 11409]]
WITH ranked AS (SELECT requested.team_id,g.game_id,g.game_date,
      row_number() OVER(PARTITION BY requested.team_id ORDER BY g.game_date DESC,g.game_id DESC) AS rank
      FROM unnest(%s::integer[]) requested(team_id) JOIN games g ON g.home_team_id=requested.team_id OR g.away_team_id=requested.team_id
      WHERE g.game_date<%s) SELECT * FROM ranked WHERE rank<=200 AND game_id=ANY(%s) ORDER BY team_id,rank;

-- Parameters: [[344, 510]]
SELECT p.baseball_player_id,p.full_name,s.external_player_id FROM baseball_players p JOIN baseball_player_sources s USING(baseball_player_id) WHERE p.baseball_player_id=ANY(%s) AND s.source_name='mlb_stats' ORDER BY p.baseball_player_id;

-- Parameters: [[344, 510], "2026-10-11 22:49:36.724858+00:00", "2026-10-11 22:49:36.724858+00:00", [26, 29, 584, 586, 11385, 11389, 11394, 11400, 11402, 11403, 11404, 11405, 11406, 11407, 11408, 11409]]
WITH ranked AS (SELECT pitching.baseball_player_id,g.game_id,g.game_date,pitching.created_at,
      row_number() OVER(PARTITION BY pitching.baseball_player_id ORDER BY g.game_date DESC,g.game_id DESC) AS rank
      FROM player_game_pitching_statistics pitching JOIN games g USING(game_id)
      WHERE pitching.baseball_player_id=ANY(%s) AND pitching.is_starter=TRUE AND g.game_date<%s AND pitching.created_at<=%s
      AND pitching.team_id IN(g.home_team_id,g.away_team_id) AND g.home_team_id IS NOT NULL AND g.away_team_id IS NOT NULL)
      SELECT * FROM ranked WHERE rank<=50 AND game_id=ANY(%s) ORDER BY baseball_player_id,rank;

-- Parameters: [[2, 5, 10, 14, 19, 25, 62, 63, 68, 76, 81]]
SELECT * FROM teams WHERE team_id=ANY(%s);

-- Parameters: [[2, 5, 10, 14, 19, 25, 62, 63, 68, 76, 81]]
SELECT * FROM baseball_team_sources WHERE team_id=ANY(%s);

-- Parameters: ["2026-07-12"]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_prediction_runs" t WHERE target_date=%s ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: ["2026-07-12"]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_daily_workflow_runs" t WHERE target_date=%s ORDER BY to_jsonb(t)::text LIMIT 10001;

-- Parameters: [[1, 2]]
SELECT to_jsonb(t)::text AS row FROM public."moneyline_daily_workflow_runs" t WHERE odds_ingestion_run_id=ANY(%s) ORDER BY to_jsonb(t)::text LIMIT 10001;