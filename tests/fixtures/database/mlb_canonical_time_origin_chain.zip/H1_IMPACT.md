# H-1 identity impact

Diagnostic projects the reviewed pre-ranking 200-team and 50-start selectors at the
trusted current read-only DB snapshot. Context teams81/76 come from the retained
cohort's prior target11410, not a newly selected inference slate. Supplied canonical
starters344/510 are the prior cutover inputs, not current probable starters. No
prediction or full034 H-1 operator is run against production033. This is not
historical/prospective readiness certification or release authority.

The independent selector is in
src/sportsmodel/operations/mlb_history_check.py:29-41,118-129; ordinary
source-mapping-filtered completeness is in
src/sportsmodel/database/mlb_completeness_repository.py:767-820.
Production 033 lacks the 034 stale/history-guard functions, so the diagnostic
does not call them or certify their admission. It preserves the date/rank
ordering, starter created_at cutoff and participant-orientation filters. It
does not execute the full starter integrity preflight or certify feature values.

29 is rank76 for White Sox81;586 rank77.26 is rank72 for Guardians76;584 rank73.
All are in the retained200 window. None is inside the supplied starter50 window.
29/584 lack mlb_stats identity and history. Mapping-filtered completeness can
exclude these invisible rows; the reviewed independent H-1 audit requires their
identity/disposition to be resolved. Both duplicates would consume history slots
and duplicate one event if blindly mapped/recovered. Their canonical counterparts
already have complete history, so ordinary absent-history recovery is inappropriate.
Current034 does not admit either extra row. Thus both pairs still block final
recovery-cohort disposition despite their real-event identities now being clear.
Four other retained groups remain identity-unresolved. Exact ranks/input cutoffs
and source/created_at filters are in DATABASE_FORENSICS and READ_ONLY_SQL.
