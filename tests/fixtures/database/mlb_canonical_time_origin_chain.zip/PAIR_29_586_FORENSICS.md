# Pair 29/586

Classification: SAME_REAL_EVENT_STALE_DUPLICATE (physical identity duplication,
not evidence of two reissued Odds events). Fixed authoritative candidate: 586.
Extra physical row: 29. No game_id proximity inference was used.

| Row | Evidence-backed labels | Decision-state finding |
| --- | --- | --- |
| 29 | STALE_MARKET_ONLY_DUPLICATE_CANDIDATE; MARKET_ONLY_HISTORY | No applicable betting decision state found |
| 586 | AUTHORITATIVE_RECORD_CANDIDATE; HAS_AUTHORITATIVE_HISTORY | No applicable betting decision state found |

The candidate label on 29 describes its identity/history role, not admission or
execution authority under 034. IDENTITY_ONLY does not describe row 29 because
its legacy market evidence is retained. Neither row is classified as a distinct,
doubleheader or rescheduled event. Their creation mechanism remains unproven.

Anonymous MLB Stats, exact July12 payload SHA256 F8A664F6CC3A0EAA640B5669CD490502F36EDC9A0087C58219D462A8D606B23B, proves one
Athletics at Chicago White Sox event:
gamePk 824574, officialDate2026-07-12, start2026-07-12T18:10:00Z, gameTypeR, Final,
doubleHeaderN, gameNumber1. No reschedule/postponement fields are supplied for
this event; no evidence supports a distinct game/doubleheader. Absence of fields
does not reconstruct all historical provider responses.

586 has the unique matching mlb_stats mapping, 1 historical
result, 2 team-stat rows and 8 pitching rows. It must
not be retired or recovered as an absent-history row. 29 has no MLB mapping,
result, team/pitching stats, prediction, evaluation, candidate/settlement or033
correction. Full catalog/semantic/inbound linkage evidence is packaged; no
applicable decision state is found. July12 prediction/workflow run context and
exact legacy ingestion-run linkage are empty. No standalone MLB publication or
Early Entry table is present; those decision/linked-run checks do not establish
filesystem-wide publication absence.

Stored schedules: 29 2026-07-12T18:11:00+00:00;
586 2026-07-12T18:10:00+00:00. The one-minute offset does not
prove postponement, rescheduling or external event reissuance. Games have no
creation timestamp, so the orphan's exact creation cause/time is not reconstructable.
Source timestamps are preserved verbatim, including naive timestamps without
inventing a timezone. The official mapping/history and orientation, not merely
timestamp proximity, establish survivor identity.

Raw provenance by row: {
  "29": {
    "snapshot_count": 96,
    "legacy_count": 8,
    "first_snapshot_time": "2026-07-12T00:41:39.636267+00:00",
    "last_snapshot_time": "2026-07-12T01:14:10.309052+00:00",
    "books": [
      "BetMGM",
      "BetOnline.ag",
      "BetRivers",
      "BetUS",
      "Bovada",
      "DraftKings",
      "FanDuel",
      "LowVig.ag",
      "MyBookie.ag"
    ],
    "markets": [
      "h2h",
      "spreads",
      "totals"
    ],
    "run_ids": [
      1,
      2
    ],
    "provider_observations": 0,
    "snapshots_with_observation_link": 0
  },
  "586": {
    "snapshot_count": 0,
    "legacy_count": 0,
    "first_snapshot_time": null,
    "last_snapshot_time": null,
    "books": [],
    "markets": [],
    "run_ids": [],
    "provider_observations": 0,
    "snapshots_with_observation_link": 0
  }
}

Provider observations: zero. First/last retained provider observation, commence
evolution, paired Odds-ID co-existence/replacement, and complete original response
contents cannot be proven from these legacy records. ODDS_TIMELINE labels actual
stored snapshot times explicitly rather than calling them provider observations.
The bounded July11/12/14 log search yielded no matching retained files. No paid
provider request or price reassignment occurred.

034 assessment: NOT_ELIGIBLE_FOR_034_DISPOSITION under the unchanged reviewed
contract. Row29 has market provenance but no snapshot with a non-null provider observation link; the SQL admission expressly requires that retained observation provenance.
The evidence supports a duplicate identity but not permission to invent missing
observations or generalize the Oct8 contract. A separately reviewed exception/
non-market retirement design would need separate review; no disposition manifest
or implementation is created here.
