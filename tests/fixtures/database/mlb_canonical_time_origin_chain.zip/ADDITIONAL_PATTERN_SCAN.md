# Cohort-only same-pattern scan

Seeds are exactly the previously identified14 IDs, not an unrestricted audit.
Same-Pacific-date/same-orientation partners:29/586,584/26,11408/11409. The fourth
directed result is11409->11408, not another pair. No additional suspect pair found.
586/26 are bounded authoritative partner context outside the14-row cohort and
are not silently added to its physical count. No dispositions were created.

Provisional logical view:14physical rows,13represented groups,9identified real-event
groups and4unresolved groups(11385,11389,11394,11400). Each unknown group is a
placeholder, not a proven real event. Two represented July groups already have
history on external canonical rows. Previous authoritative evidence for six other
groups and approved Oct8 identity is labeled as prior evidence, not refreshed
provider confirmation. No final reconciliation/recovery manifests are generated.
