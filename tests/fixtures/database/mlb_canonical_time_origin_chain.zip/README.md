# Remaining MLB duplicate forensics1.4.0

RECOVERY_COHORT_STILL_AMBIGUOUS

Both July pairs are the same real event with duplicate physical identities, not
doubleheaders/reschedules supported by evidence. Authoritative candidates586
(824574) and26(823842) already have history. Neither extra row satisfies current034:
29 lacks observation-linked provenance;584 is source-less/market-less. The fourteen
row cohort provisionally represents13groups, four still identity-unresolved.

Evidence: native127.0.0.1:5432/sportsmodel/PG16, exact001–033 verified before any
game query. Two READ ONLY REPEATABLE READ snapshots, rollback/close, SELECT-only
lexical guard and full scoped raw-row digest equality. One bounded anonymous MLB
Stats request, exactJuly12 raw response SHA256F8A664F6CC3A0EAA640B5669CD490502F36EDC9A0087C58219D462A8D606B23B; no paid Odds API.
This task's production access was read-only investigation, not production mutation.
Full workflow/service operational health was not evaluated; inference remains held.

CSV fields preserve ISO/naive timestamps and external IDs verbatim, round-tripped
against source values; no Excel type coercion, price/model/performance analysis or
market reassignment. Nulls remain empty fields, not invented zero timestamps.
Full hashes attest prices/lines while unnecessary monetary/model/stats content is
omitted from dependency exports. All metadata/linkage counts remain preserved.

Git/source/migration034 hash matches reviewed successor;033remains applied boundary.
No development/production files or Git state changed. No migration/DBwrite/ledger/
reconciliation/recovery/task/service/workflow/prediction/publication/retraining/NFL
action. No disposition or final recovery manifest. Any future retirement or history
operation needs fresh evidence, independent review and explicit action authority.

See pair reports, dependency/H1/eligibility comparison, exact executed SQL and logical
CSV. Missing historical provider observations and creation cause are stated as
limitations, not inferred facts. Package hashes support independent review.
