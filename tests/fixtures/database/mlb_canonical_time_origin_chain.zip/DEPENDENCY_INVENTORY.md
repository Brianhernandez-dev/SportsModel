# Scoped dependency inventory

All four roots, direct/semantic game references, exact external Odds IDs,
converged inbound game/market/prediction linkage and bounded outbound context.
Run/book context never fans out into unrelated games merely sharing a run.
Catalog/FK inventory and every executed SELECT are included. Zero rows are not
treated as missing tables. NFL relations are zero-row domain checks only; no NFL
data/code was changed or analyzed. Stats exports are limited to identity/PIT fields,
not batting/performance; raw row digests attest the full rows.

| Relation | Rows | Category |
| --- | ---: | --- |
| game_results | 0 | AUTHORITATIVE_HISTORY |
| game_sources | 4 | IDENTITY_ONLY |
| games | 4 | IDENTITY_ONLY |
| historical_games | 2 | AUTHORITATIVE_HISTORY |
| market_analysis | 0 | BETTING_DECISION_STATE |
| model_predictions | 0 | BETTING_DECISION_STATE |
| moneyline_game_predictions | 0 | BETTING_DECISION_STATE |
| moneyline_paper_candidate_settlements | 0 | BETTING_DECISION_STATE |
| moneyline_prediction_market_evaluations | 0 | BETTING_DECISION_STATE |
| nfl_game_source_observations | 0 | OTHER — domain reference check only, zero rows |
| nfl_games | 0 | OTHER — domain reference check only, zero rows |
| nfl_moneyline_game_predictions | 0 | OTHER — domain reference check only, zero rows |
| nfl_moneyline_market_evaluation_contributors | 0 | OTHER — domain reference check only, zero rows |
| nfl_moneyline_market_evaluations | 0 | OTHER — domain reference check only, zero rows |
| nfl_odds_provider_event_mappings | 0 | OTHER — domain reference check only, zero rows |
| nfl_official_pregame_evidence | 0 | OTHER — domain reference check only, zero rows |
| nfl_team_game_statistics | 0 | OTHER — domain reference check only, zero rows |
| nfl_team_game_statistics_source_observations | 0 | OTHER — domain reference check only, zero rows |
| odds_ingestion_runs | 2 | RAW_MARKET_PROVENANCE |
| odds_market_snapshots | 168 | RAW_MARKET_PROVENANCE |
| odds_provider_event_canonical_corrections | 0 | BETTING_DECISION_STATE |
| odds_provider_event_observations | 0 | RAW_MARKET_PROVENANCE |
| odds_snapshots | 9 | RAW_MARKET_PROVENANCE |
| player_game_pitching_statistics | 20 | AUTHORITATIVE_HISTORY |
| sportsbooks | 9 | RAW_MARKET_PROVENANCE |
| team_game_statistics | 4 | AUTHORITATIVE_HISTORY |

WORKFLOW_STATE/PUBLICATION_STATE: July12 moneyline_prediction_runs and
moneyline_daily_workflow_runs, plus exact legacy ingestion-run workflow linkage,
are empty. No standalone MLB Early Entry/publication table is present in the
catalog; candidate/evaluation state is represented by the applicable moneyline
decision tables, all empty for the four roots. This is database linkage evidence,
not a claim that every historical filesystem output has been recovered.
